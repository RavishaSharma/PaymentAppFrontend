import { Component, OnInit } from '@angular/core';
import { PaymentService } from '../payment.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-payment',
  templateUrl: './add-payment.component.html',
  styleUrls: ['./add-payment.component.css']
})
export class AddPaymentComponent implements OnInit {
  payment: any = {};
  currencies: string[] = ['USD', 'EUR', 'INR', 'JPY', 'GBP', 'AUD', 'CAD'];

  constructor(private paymentService: PaymentService, private snackBar: MatSnackBar) {}

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.validatePayment()) {
      this.paymentService.addPayment(this.payment).subscribe(
        () => {
          this.snackBar.open('Payment added successfully', 'Close', { duration: 3000 });
          this.resetForm();
        },
        (error) => {
          console.error('Error adding payment:', error);
          this.snackBar.open('Error adding payment', 'Close', { duration: 3000 });
        }
      );
    }
  }

  validatePayment(): boolean {
    if (!this.payment.payee_first_name || !this.payment.payee_last_name || !this.payment.due_amount || !this.payment.currency || !this.payment.payee_due_date) {
      this.snackBar.open('Please fill all required fields', 'Close', { duration: 3000 });
      return false;
    }
    return true;
  }

  resetForm(): void {
    this.payment = {};
  }
}
